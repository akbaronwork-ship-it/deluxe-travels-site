# Deluxe Tours & Travels 🌍✈️

A modern, user-friendly travel agency website designed for **Deluxe Tours & Travels**.  

## 🚀 Features
- Hero banner with CTA
- Popular destinations photo gallery
- Booking form
- Testimonials
- About Us section
- Mobile responsive

## 📂 Files
- index.html (Main website file)
- README.md (Documentation)

## ⚡ Deployment
Host using Netlify, GitHub Pages, or Vercel by uploading `index.html`.

